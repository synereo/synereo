package com.protegra

/* User: jklassen
*/

import org.specs._
import org.specs.util._
import org.specs.runner.JUnit4
import org.specs.runner.ConsoleRunner

class RemoteClientTest
  extends JUnit4(RemoteClientTestSpecs)

object RemoteClientTestSpecsRunner
  extends ConsoleRunner(RemoteClientTestSpecs)

object RemoteClientTestSpecs extends Specification
{

  "basic send " should {
    "send values over rabbitmq queue" in {
      val client = new RemoteClient
      client.hammer
    }
  }
}
