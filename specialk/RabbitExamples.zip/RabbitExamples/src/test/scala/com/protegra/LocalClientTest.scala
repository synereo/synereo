package com.protegra

/* User: jklassen
*/

import org.specs._
import org.specs.util._
import org.specs.runner.JUnit4
import org.specs.runner.ConsoleRunner

class LocalClientTest
  extends JUnit4(LocalClientTestSpecs)

object LocalClientTestSpecsRunner
  extends ConsoleRunner(LocalClientTestSpecs)

object LocalClientTestSpecs extends Specification
{

  "basic send " should {
    "send values over rabbitmq queue" in {
      val client = new LocalClient
      client.hammer
    }
  }
}
