package com.protegra

import com.rabbitmq.client._
import java.io._

class RemoteClient
{
  def getDefaultConnectionFactory(): ConnectionFactory =
  {
    val factory = new ConnectionFactory()
    factory.setUsername("guest")
    factory.setPassword("guest")
    factory.setVirtualHost("/")
    factory.setRequestedHeartbeat(0)
    factory
  }

  val host = "172.23.32.158"
  val port = 5672
  val factory = getDefaultConnectionFactory()
  val connection = factory.newConnection(Array {new Address(host, port)})
  val routingKey = "route"

  def send(msg: String) : Unit =
  {
    send("myExchange", "myQueue", msg)
  }

  def send(exchange: String, queue: String, msg: String) =
  {
    val channel = connection.createChannel()
    channel.exchangeDeclare(exchange, "direct")
    //queueDeclare(java.lang.String queue, boolean durable, boolean exclusive, boolean autoDelete, java.util.Map<java.lang.String,java.lang.Object> arguments)
    channel.queueDeclare(queue, true, false, false, null);
    channel.queueBind(queue, exchange, routingKey)

    val bytes = new ByteArrayOutputStream
    val store = new ObjectOutputStream(bytes)
    store.writeObject(msg)
    store.close
    println("sending message:" + msg)
    channel.basicPublish(exchange, routingKey, null, bytes.toByteArray)
  }

  def hammer() =
  {
    for ( i <- 1 to 100 ) {
      val msg = "I'm a test message" + i
      send(msg)
    }
  }

  //  def receive(exchange: String, queue: String) =
  //  {
  //    receive("myExchange", "myQueue")
  //  }
  //
  //  def receive(exchange: String, queue: String) =
  //  {
  //    channel.exchangeDeclare(exchange, "direct")
  //    channel.queueDeclare(queue, true, false, false, null);
  //    channel.queueBind(queue, exchange, "routeroute")
  //    // Use the short version of the basicConsume method for convenience.
  //    channel.basicConsume(queue, false, new SerializedConsumer(channel, this))
  //  }

}